window.onscroll = function() {
  olookApp.mediator.publish('window.onscroll');
}
;
