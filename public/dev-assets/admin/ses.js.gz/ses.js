$(function(){
  if(document.getElementById("canvas")){
    var barChartData = {
      labels : ["Bounces","Complaints","Delivery Attempts","Rejects"],
      datasets : [
        {
          fillColor : "rgba(220,220,220,0.5)",
          strokeColor : "rgba(220,220,220,1)",
          data : window.email_info
        },
      ]
    }

    // bounces   complaints  delivery_attempts   rejects
    var myLine = new Chart(document.getElementById("canvas").getContext("2d")).Bar(barChartData, { scaleOverlay : true});
  };
});
