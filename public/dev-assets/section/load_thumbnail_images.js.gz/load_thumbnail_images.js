loadThumbnails = function() {
  new ImageLoader().load("async");
}

window.addEventListener('load', loadThumbnails);
