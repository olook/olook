StringUtils = {
  isEmpty: function(str){
    return !(str && str!=''); 
  }
};
