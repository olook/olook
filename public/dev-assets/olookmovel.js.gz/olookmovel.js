$(function() {
  $(".instagram_pictures").instagram({
    hash: 'olookmovel',
    show: 9,
    image_size: 'thumbnail',
    clientId: 'a818002be5404483a41fca01c0642840'
  });
});
